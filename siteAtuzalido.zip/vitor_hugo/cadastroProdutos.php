<?php
		session_start();
	
		$nome = $_POST["nome"];
		$descricao = $_POST["descricao"]; 
		/*$senha_segura = password_hash($senha, PASSWORD_DEFAULT);*/
		
		include("conexao.php");
		$cadastro = mysqli_query($conection, "INSERT INTO produtos(nome, descricao) VALUES ('$nome', '$descricao')");
		header('Location: dashboard.php?isSucess=true');
?>
