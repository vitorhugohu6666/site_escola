<?php
session_start();
if (!isset($_SESSION["acesso"])) {

    header('Location: login.php?erro=2');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>

     <!-- Custom fonts for this template-->
     <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

</head>
<body>
    <form action="atualizarProduto.php" method="post">
        <h1>Editar Usuário</h1>

        <label for="id">Id: </label>
        <input type="number" name="id" id="id" required placeholder="Id do produto">

       <label for="nome">Nome: </label>
       <input type="text"  name="nome" id="nome" required placeholder="Nome do produto">

        <label for="senha">Descrição: </label>
        <input type="text" name="descricao" id="descricao" required placeholder="Descrição do produto" >
        <button type="submit">Alterar</button>
    </form>
</body>
</html>