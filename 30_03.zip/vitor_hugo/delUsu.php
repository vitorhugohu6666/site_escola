<?php
session_start();
include("conexao.php");

$id_usuario = $_GET["id"];

mysqli_query($conection, "DELETE FROM usuarios WHERE id = $id_usuario");

header("Location: dashboard.php?deletar=2");
exit;
?>