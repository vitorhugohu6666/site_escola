<?php

$mobile = FALSE;
$user_agents = array("iPhone", "iPad", "Android", "webOS", "BlackBerry", "iPod", "Symbian", "IsGeneric");

foreach ($user_agents as $user_agent) {
	if (strpos($_SERVER['HTTP_USER_AGENT'], $user_agent) !== FALSE) {
		$mobile = TRUE;
		$modelo = $user_agent;
		break;
	}
}

/* a funcao strpos verifica se a string $user_agent
        está contida na string $_server
*/
?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Bem-vindo</title>
	<!-- CSS Boostrapp -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<style>
		.img-fluid {
			height: 250px;
			width: 300px;
			border-radius: 20px;
			margin-top: 20px;
	
		}

		
		.img-mobile {
			height: 100px;
			width: 100px;
			border-radius: 10px;
			margin-top: 20px;
		}

		.textoMobile {
			font-size: small;
		}

		.spinner-border-mobile {
			 width: 36px;
   			 height: 36px;
		}
		
	</style>
</head>

<script type="text/javascript">
	function redirect() {
    window.location = "login.php";
}

	window.onload = function() {
    	setTimeout(redirect, 2000);
	}
</script>

<body class="bg-primary">

	<?php if ($mobile): ?>
		<center>

			<img src="imagens/loja.png" class="img-mobile" alt="Logo Marca">

		</center>

		<center>

			<div class="spinner-border text-light spinner-border-mobile" role="status">
				<span class="visually-hidden">Carregando...</span>
			</div>
		</center>

		<center>
			<p class="text-light textoMobile">Bem-vindo! Sistema Mobile...</p>
		</center>

	<?php else: ?>

		<center>

		<img src="imagens/loja.png" class="img-fluid" alt="Logo Marca">

		</center>

		<center>

			<div class="spinner-border text-light" role="status">
				<span class="visually-hidden">Carregando...</span>
			</div>
		</center>

		<center>
			<p class="text-light textoMobile">Bem-vindo! Sistema Desktop...</p>
		</center>

	<?php endif; ?>

</body>

</html>