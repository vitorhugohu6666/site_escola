<?php
include("conexao.php");

$id = $_GET["id"];

mysqli_query($conection, "DELETE FROM produtos WHERE id = $id");

header("Location: dashboard.php?deletar=2");

exit;
?>