<?php
session_start();

$mobile = FALSE;
$user_agents = array("iPhone", "iPad", "Android", "webOS", "BlackBerry", "iPod", "Symbian", "IsGeneric");

foreach ($user_agents as $user_agent) {
	if (strpos($_SERVER['HTTP_USER_AGENT'], $user_agent) !== FALSE) {
		$mobile = TRUE;
		$modelo = $user_agent;
		break;
	}
}

/* a funcao strpos verifica se a string $user_agent
        está contida na string $_server
      */
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sistema de Login</title>
	<!-- CSS Boostrapp -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="estilo/signin.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
	<style>
		.bd-placeholder-img {
			font-size: 1.125rem;
			text-anchor: middle;
			-webkit-user-select: none;
			-moz-user-select: none;
			user-select: none;
		}

		@media (min-width: 768px) {
			.bd-placeholder-img-lg {
				font-size: 3.5rem;
			}
		}

		img {
			border-radius: 8px;
		}

		.alert-custom {
			color: black;
			background-color: #86f4a4ff;
		}
	</style>
</head>

<body class="text-center">

	<main class="form-signin">

	<?php if ($mobile): ?>

		<form method="POST" action="valida_login.php" class="form-signin">

			<img src="imagens/loja.png" alt="Logo Marca" class="mb-4" width="50px" height="50px">
			<h1 class="h3 mb-3 fw-normal">Acesso ao sistema</h1>

			<div class="form-floating fleXMobile">
				<input type="text" class="form-control" id="nome" name="nome" required placeholder="Digite seu nome de usuario">
				<label for="nome">Nome:</label>
			</div>

			<div class="form-floating fleXMobile">
				<input type="password" class="form-control" id="senha" name="senha" required placeholder="Digite sua senha" minlength="4" maxlength="6">
				<label for="senha">Senha:</label>

			</div>

			<div class="checkbox mb-3">
				<label>
					<input type="checkbox" name="lembrar" value="1"> Me-lembra
				</label>
			</div>

			<button class="w-100 btn btn-lg btn-primary" type="submit"><i class="bi bi-person-lock"></i> Entrar</button>

			<br>
			<br>

			<a href="esqueceuSenha.php" style="text-align: left">Esqueci minha senha</a>

			<p class="mt-5 mb-3 text-muted">&copy; desde <span id="ano"></span></p>


		</form>

		<?php else: ?>

			<form method="POST" action="valida_login.php" class="form-signin">

			<img src="imagens/loja.png" alt="Logo Marca" class="mb-4" width="50px" height="50px">
			<h1 class="h3 mb-3 fw-normal">Acesso ao sistema</h1>

			<div class="form-floating fleXMobile">
				<input type="text" class="form-control" id="nome" name="nome" required placeholder="Digite seu nome de usuario">
				<label for="nome">Nome:</label>
			</div>

			<div class="form-floating fleXMobile">
				<input type="password" class="form-control" id="senha" name="senha" required placeholder="Digite sua senha" minlength="4" maxlength="6">
				<label for="senha">Senha:</label>

			</div>

			<div class="checkbox mb-3">
				<label>
					<input type="checkbox" name="lembrar" value="1"> Me-lembra
				</label>
			</div>

			<button class="w-100 btn btn-lg btn-primary" type="submit"><i class="bi bi-person-lock"></i> Entrar</button>

			<br>
			<br>

			<a href="esqueceuSenha.php" style="text-align: left">Esqueci minha senha</a>

			<p class="mt-5 mb-3 text-muted">&copy; desde <span id="ano"></span></p>


		</form>

		
		<?php endif; ?>

	</main>

	<script>
		let ano = window.document.getElementById("ano");
		let date = new Date();
		let anoComp = date.getFullYear();
		ano.innerHTML = anoComp;
	</script>

	<!-- T2.Y.ih*4)lFTD!J    senha BANCO  -->
</body>

</html>