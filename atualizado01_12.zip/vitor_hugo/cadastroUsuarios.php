<?php
		session_start();

		$usuario = $_POST["nome"];
		$senha = $_POST["senha"]; 
		$email = $_POST["email"];
		$senha_segura = password_hash($senha, PASSWORD_DEFAULT);
		
		include("conexao.php");
		$verificaE = mysqli_query($conection, "SELECT * FROM usuarios WHERE email = '$email'");
		if(mysqli_num_rows($verificaE) > 0) {
			header('Location: dashboard.php?emailError=true');
			exit;
		} else {
			$cadastro = mysqli_query($conection, "INSERT INTO usuarios(nome, senha, email) VALUES ('$usuario', '$senha_segura', '$email')");
			header('Location: dashboard.php?isSucess=true');
			exit;
		}
?>

